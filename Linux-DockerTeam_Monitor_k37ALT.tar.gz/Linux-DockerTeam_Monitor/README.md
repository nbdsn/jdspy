# Monitor
监控库

# 说明
几个群管没事收集来的，尊重原作者。
方便区分，加了落幕二字是为了方便区分JS 防止删错JS

# 交流群

| QQ群号  | 群昵称 |
| ------------- | ------------- |
| [227680494](https://jq.qq.com/?_wv=1027&k=vXfuJ8Fi)  | Linux&&Docker交流群 |
| 674895374 | Linux&&Docker交流群1（暂不加人）  |
| [608055886](https://jq.qq.com/?_wv=1027&k=fQsAqoE4) | Linux&&Docker交流群3 |
| [420035660](https://jq.qq.com/?_wv=1027&k=wXO8dpSJ) | 落幕笔记（落幕笔记官方群）|
| [176196599](https://jq.qq.com/?_wv=1027&k=leFuNDj5) | 随缘（一曲横笛官方群） |


# 拉库命令
```
ql repo https://github.com/Linux-DockerTeam/Monitor.git "jd_|m_|pkc_|jdCookie" "activity|backUp" "^jd[^_]|USER|utils|function"
```
